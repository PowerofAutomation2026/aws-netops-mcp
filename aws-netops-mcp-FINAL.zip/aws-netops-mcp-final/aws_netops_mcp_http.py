"""
AWS NetOps MCP — HTTP wrapper for Azure Container Apps / Copilot Studio.

This wraps the local MCP server (aws_netops_mcp.py) with a streamable HTTP
transport so it can be called by remote MCP clients like Microsoft Copilot
Studio, GitHub Copilot for Azure, or any HTTP-capable AI agent.

================================================================================
 CRITICAL FIXES BAKED IN (do NOT remove these — each one is hard-won)
================================================================================

1. DNS REBINDING PROTECTION (MCP 1.27+)
   MCP 1.27 added security middleware that ONLY allows localhost in the Host
   header by default. Azure's load balancer sends the public FQDN, which gets
   rejected as "Invalid Host header". The 3 transport_security lines below
   disable this for cloud deployments where ingress already protects you.

2. UVICORN PROXY HEADERS
   Azure Container Apps sits behind a load balancer that rewrites Host /
   X-Forwarded-Host. forwarded_allow_ips="*" + proxy_headers=True tell
   Uvicorn to trust those headers instead of rejecting them.

3. STATELESS HTTP MODE
   stateless_http=True is required when running behind a load balancer that
   may route subsequent requests to different replicas.

4. FLUSH=TRUE ON PRINTS
   Container logs are line-buffered. Without flush=True, startup messages
   only appear AFTER the first request, making debugging painful.

5. HEALTH ENDPOINT
   Container Apps probes /health with GET. The /mcp endpoint only accepts
   POST. We add a separate Starlette route so probes pass.

If you remove any of these, deployment WILL fail. They are not optional.
================================================================================
"""
import os
import sys

# Make sure we can import the sibling aws_netops_mcp.py
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

# Import the existing MCP — this registers all tools on `core.mcp`
import aws_netops_mcp as core

# ─────────────────────────────────────────────────────────────────────────────
# FIX 1 + FIX 3: Stateless HTTP + DNS rebinding bypass for cloud ingress
# ─────────────────────────────────────────────────────────────────────────────
core.mcp.settings.stateless_http = True
core.mcp.settings.transport_security.enable_dns_rebinding_protection = False
core.mcp.settings.transport_security.allowed_hosts = ["*"]
core.mcp.settings.transport_security.allowed_origins = ["*"]

# Build the ASGI app from the already-populated FastMCP instance
app = core.mcp.streamable_http_app()

# ─────────────────────────────────────────────────────────────────────────────
# FIX 5: /health endpoint for Container Apps probes
# ─────────────────────────────────────────────────────────────────────────────
from starlette.responses import JSONResponse
from starlette.routing import Route


async def health(_request):
    """Return tool count so we can verify the right code is running."""
    tool_count = len(core.mcp._tool_manager._tools) if hasattr(core.mcp, "_tool_manager") else "unknown"
    return JSONResponse({"status": "ok", "tools": str(tool_count)})


app.routes.append(Route("/health", health, methods=["GET"]))


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", 8000))
    # FIX 4: flush=True so logs appear immediately, not after first request
    print(f"AWS NetOps MCP (HTTP) starting on port {port}", flush=True)
    print(f"  MCP endpoint:    http://0.0.0.0:{port}/mcp", flush=True)
    print(f"  Health endpoint: http://0.0.0.0:{port}/health", flush=True)
    print(f"  Stateless mode:  {core.mcp.settings.stateless_http}", flush=True)
    print(f"  DNS protection:  {core.mcp.settings.transport_security.enable_dns_rebinding_protection}", flush=True)

    # ─────────────────────────────────────────────────────────────────────────
    # FIX 2: Trust X-Forwarded-* headers from Azure load balancer
    # ─────────────────────────────────────────────────────────────────────────
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=port,
        forwarded_allow_ips="*",
        proxy_headers=True,
    )
