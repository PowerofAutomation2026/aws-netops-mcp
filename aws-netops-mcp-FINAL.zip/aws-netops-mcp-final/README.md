# AWS NetOps MCP

> **104 read-only AWS troubleshooting tools for AI agents.** Plug into Claude Desktop or Microsoft Copilot Studio — same brain, two front doors. Production-ready Azure Container Apps deployment in 10 minutes. **All 21 deployment fixes baked in — works on the first try.**

[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![MCP](https://img.shields.io/badge/MCP-1.27+-purple.svg)](https://modelcontextprotocol.io/)
[![AWS Read-Only](https://img.shields.io/badge/AWS-ReadOnly-orange.svg)](#-security)
[![Azure](https://img.shields.io/badge/Azure-Container%20Apps-0078d4.svg)](https://azure.microsoft.com/products/container-apps)
[![Copilot Studio](https://img.shields.io/badge/Copilot%20Studio-Compatible-7c3aed.svg)](https://copilotstudio.microsoft.com)

---

## 🎬 Demo

```
You: "Why can't web-server-prod-3 reach the database?"

Agent: [calls find_instance, describe_security_group, query_flow_logs]

Security group sg-0abc123 attached to web-server-prod-3 has no
outbound rule allowing port 5432 to subnet 10.0.2.0/24.
Flow Logs show 47 REJECT events in the last hour.

Suggested fix:
  aws ec2 authorize-security-group-egress \
    --group-id sg-0abc123 \
    --protocol tcp --port 5432 --cidr 10.0.2.0/24
```

That answer in 4 seconds. From plain English. In Microsoft Teams.

---

## 🚀 Quick deploy (3 steps, 10 minutes)

### 1. Set AWS credentials

Open the credentials CSV in **Notepad**, then in PowerShell:

```powershell
$env:AWS_ACCESS_KEY_ID = "AKIA..."        # paste from Notepad — single Ctrl+V
$env:AWS_SECRET_ACCESS_KEY = "..."         # paste from Notepad — single Ctrl+V
$env:AWS_DEFAULT_REGION = "us-east-1"
```

### 2. Pre-flight check (30 seconds)

Verifies all 21 fixes are in place BEFORE you commit to a 10-minute deploy:

```powershell
cd aws-netops-mcp
.\copilot-studio\PreFlight-Check.ps1
```

You should see:

```
✓ ALL CRITICAL CHECKS PASSED
Ready to deploy. Run: .\Deploy-AwsNetOpsMcp.ps1
```

### 3. Deploy (~10 minutes)

```powershell
.\copilot-studio\Deploy-AwsNetOpsMcp.ps1
```

The script handles all 9 stages and prints your MCP endpoint URL when done.

---

## 🛠️ The 21 fixes — every one is baked in

This package was built from a real deployment journey that hit every cliff possible. Each fix is now automated:

| Fix | What it solves | Where it's applied |
|---|---|---|
| **#1** | "Invalid Host header" — MCP 1.27 DNS rebinding protection | `aws_netops_mcp_http.py` |
| **#2** | Azure FQDN host whitelisting | `aws_netops_mcp_http.py` |
| **#3** | CORS origin whitelisting | `aws_netops_mcp_http.py` |
| **#4** | Multi-replica state issues | `aws_netops_mcp_http.py` |
| **#5** | Azure load balancer header forwarding | `aws_netops_mcp_http.py` |
| **#6** | Container log buffering (immediate output) | `aws_netops_mcp_http.py` |
| **#7** | Container Apps health probes (GET /health) | `aws_netops_mcp_http.py` |
| **#8** | Cloud Build buildpack hijack (Dockerfile in subfolder) | `Dockerfile` at repo root + PreFlight check |
| **#9** | COPY-target file paths | All sources at repo root |
| **#10** | PowerShell paste duplication (`InvalidClientTokenId`) | PreFlight + Deploy script |
| **#11** | `--output none` not supported on `containerapp up` | Deploy script |
| **#12** | PowerShell `$env:` expansion fails on `--env-vars` | Deploy script (separate `update --set-env-vars` step) |
| **#13** | Zombie containers from failed deploys | Deploy script (auto-detect & clean) |
| **#14** | PowerShell `curl` aliasing issues | Deploy + Test scripts use `Invoke-WebRequest` |
| **#15** | Plain GET to `/mcp` looks broken | Deploy + Test use proper JSON-RPC initialize |
| **#16** | Debugging without rebuild loops | Documented (Azure Portal Console) |
| **#17** | Live MCP settings introspection | Documented (`python -c` patterns) |
| **#18** | `python:slim` has no util tools | Documented |
| **#19** | Copilot Studio Generative orchestration | Printed in next-steps |
| **#20** | "Connector request failed" cache issue | Printed in next-steps |
| **#21** | 70-tool UI display cap (cosmetic) | Printed in next-steps |

📄 See `THE-21-FIXES-EXPLAINED.md` for full root cause + solution for each one.

---

## 📦 What's in this package

```
aws-netops-mcp/
├── aws_netops_mcp.py                  ← The 104 tools (Claude Desktop runs this)
├── aws_netops_mcp_http.py             ← HTTP wrapper with FIX #1-7 baked in
├── Dockerfile                          ← Lives at root (FIX #8)
├── requirements.txt                    ← Claude Desktop deps
├── requirements-http.txt               ← Container Apps deps
├── CLAUDE-DESKTOP-CONFIG-EXAMPLE.json  ← Sample Claude Desktop config
├── README.md                           ← You are here
├── THE-21-FIXES-EXPLAINED.md          ← Detailed lessons learned
├── LICENSE                             ← MIT
├── .gitignore
├── iam-policy/
│   └── NetOpsMcpReadOnly.json          ← Custom 28-statement read-only policy
└── copilot-studio/
    ├── PreFlight-Check.ps1             ← 🆕 Run this FIRST (30 sec)
    ├── Deploy-AwsNetOpsMcp.ps1         ← Main deploy with all 21 fixes
    ├── Test-AwsNetOpsMcp.ps1           ← Verify after deploy
    ├── Undeploy-AwsNetOpsMcp.ps1       ← Clean teardown
    └── README.md
```

---

## 🤖 Claude Desktop quickstart (5 minutes, optional)

If you want the same brain on your laptop too:

```bash
git clone <repo>
cd aws-netops-mcp
pip install -r requirements.txt

aws configure --profile netops    # paste your AWS keys here
```

Edit `%APPDATA%\Claude\claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "aws-netops": {
      "command": "python",
      "args": ["C:\\Projects\\aws-netops-mcp\\aws_netops_mcp.py"],
      "env": {
        "AWS_PROFILE": "netops",
        "AWS_DEFAULT_REGION": "us-east-1"
      }
    }
  }
}
```

Restart Claude Desktop, ask: *"Who am I in AWS?"*

See `CLAUDE-DESKTOP-CONFIG-EXAMPLE.json` for full sample.

---

## 💡 Connect Copilot Studio (5 minutes after deploy)

The deploy script prints your URL at the end. Then:

1. Open https://copilotstudio.microsoft.com
2. Open or create your agent
3. **CRITICAL [FIX #19]:** Settings → Generative AI → Orchestration = **Generative** (not Classic!)
4. Tools → + Add a tool → New tool → Model Context Protocol
5. Server URL: `https://YOUR-FQDN.eastus.azurecontainerapps.io/mcp`
6. Authentication: None
7. Click Create → "Discovered 104 tools" ✅
8. Test: *"Who am I in AWS?"*

⚠️ **If "Connector request failed" [FIX #20]:** Don't refresh — DELETE the MCP entry and re-add. The refresh button often caches the bad state.

📝 **Note [FIX #21]:** Copilot Studio's UI caps display at 70 tools. All 104 are still callable — this is cosmetic, not a bug.

---

## 🔒 Security

- ✅ IAM user is locked to AWS-managed `ReadOnlyAccess` (or the custom 28-statement policy in `iam-policy/`)
- ✅ Custom policy ends with explicit `Deny` on `*:Create*`, `*:Delete*`, `*:Modify*`, `*:Update*`, etc.
- ✅ Agent can investigate but cannot modify, delete, or terminate anything
- ✅ AWS credentials are stored as Container Apps secrets (encrypted at rest)
- ⚠️ **Recommended for production:** add API key middleware to `/mcp` endpoint
- ⚠️ **Recommended:** rotate AWS access keys every 90 days
- ⚠️ **Recommended:** add IAM permission boundary to prevent privilege escalation

---

## 💰 Cost

| Item | Always-on | Scale-to-zero |
|---|---|---|
| Azure Container Apps (1 replica, 0.5 vCPU / 1 GiB) | ~$10/mo | ~$0 |
| Azure Container Registry (Basic) | ~$2/mo | ~$2/mo |
| AWS API calls (read-only) | $0 | $0 |
| **Total** | **~$12/month** | **~$2/month** |

Use `-MinReplicas 0` to enable scale-to-zero (cold start ~5 sec on first request).

---

## 🐛 Troubleshooting

### Pre-flight check fails

The PreFlight script tells you exactly which fix is missing and how to apply it. Most common:

- **FIX #10 fails (key length wrong):** Re-paste AWS credentials from Notepad with single Ctrl+V
- **FIX #1-7 fail (wrapper missing fixes):** Use the `aws_netops_mcp_http.py` from this package
- **FIX #8 fails (Dockerfile not at root):** Move it to repo root, not in subfolder

### Deploy succeeds but Copilot Studio gets "Invalid Host header"

The wrapper's DNS rebinding fix isn't taking effect. Check FIX #1-3 in `aws_netops_mcp_http.py`. Also check the running container with Azure Portal Console:

```bash
python -c "from mcp.server.fastmcp import FastMCP; \
  m=FastMCP('x'); print(m.settings.transport_security)"
```

If you see `enable_dns_rebinding_protection=True`, the fix isn't applied.

### Deploy succeeds but Copilot Studio finds 0 tools

You forgot **FIX #19** — Settings → Generative AI → Orchestration must be **Generative**, not Classic.

### "Connector request failed" after fixing things

**FIX #20** — Don't click Refresh. DELETE the MCP entry and re-add it from scratch.

---

## 📚 Read the full story

The complete deployment journey, with the 4 cliffs we hit and how we fixed them, is on [Power of Automation](https://powerofautomation2025.blogspot.com).

---

## 📄 License

MIT — fork it, break it, make it yours.

## 🙏 Acknowledgments

- [Anthropic](https://anthropic.com) for the MCP standard and Python SDK
- [Microsoft](https://copilotstudio.microsoft.com) for Copilot Studio MCP support
- The countless Azure docs, GitHub issues, and Stack Overflow threads
