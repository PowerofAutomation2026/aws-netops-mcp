# Copilot Studio Deployment Scripts

This folder contains 4 PowerShell scripts. Run them in this order:

| Order | Script | When to run | Time |
|---|---|---|---|
| 1 | **`PreFlight-Check.ps1`** | Before deploying | 30 sec |
| 2 | **`Deploy-AwsNetOpsMcp.ps1`** | Main deployment | ~10 min |
| 3 | **`Test-AwsNetOpsMcp.ps1`** | After deploy, anytime to verify | 1 min |
| 4 | **`Undeploy-AwsNetOpsMcp.ps1`** | When done, to stop billing | 1 min |

## The 3-step deploy flow

### Step 1: Pre-flight (30 seconds)

From the **package root** (NOT this folder):

```powershell
$env:AWS_ACCESS_KEY_ID = "AKIA..."
$env:AWS_SECRET_ACCESS_KEY = "..."
$env:AWS_DEFAULT_REGION = "us-east-1"

.\copilot-studio\PreFlight-Check.ps1
```

Verifies all 21 fixes are in place. Catches problems in 30 seconds instead of 10 minutes into a failed deploy.

You should see:
```
✓ ALL CRITICAL CHECKS PASSED
Ready to deploy. Run: .\Deploy-AwsNetOpsMcp.ps1
```

### Step 2: Deploy (~10 minutes)

```powershell
.\copilot-studio\Deploy-AwsNetOpsMcp.ps1
```

The 9 stages:

1. **Prerequisites** (FIX #8, #9, #10) — Verifies files at root + AWS key length
2. **CLI extension** — Installs/updates `containerapp` extension
3. **Resource providers** — Registers Microsoft.App, OperationalInsights, ContainerRegistry
4. **Resource group** — Creates `rg-aws-netops-mcp`
5. **Container Apps environment** — The slow step (~2 min)
6. **Zombie cleanup** (FIX #13) — Auto-detects and cleans failed-deploy artifacts
7. **Build & deploy** (FIX #11, #12) — Azure Cloud Build builds, pushes, deploys
8. **Env vars** (FIX #12) — Applies AWS credentials in separate update step
9. **Verification** (FIX #14, #15) — Tests `/health` and `/mcp` endpoints

Total time: ~8-10 minutes. **Idempotent** — safe to re-run.

### Step 3: Test (anytime)

```powershell
.\copilot-studio\Test-AwsNetOpsMcp.ps1
```

Runs 4 tests:
1. Container app status
2. Public FQDN retrieval
3. `/health` endpoint
4. `/mcp` JSON-RPC initialize handshake

## Customize the deploy

```powershell
.\copilot-studio\Deploy-AwsNetOpsMcp.ps1 `
    -ResourceGroup "my-custom-rg" `
    -Location "westus2" `
    -AppName "my-mcp" `
    -MinReplicas 0 `      # scale-to-zero (~$1/month)
    -MaxReplicas 5 `
    -Force                 # skip confirmation prompt
```

## Cleanup when done

```powershell
.\copilot-studio\Undeploy-AwsNetOpsMcp.ps1
```

Deletes the entire resource group (Container App, ACR, Log Analytics, etc.) — stops all billing.

## Troubleshooting

If the deploy fails, the script prints which of the 21 fixes is the likely cause. See `THE-21-FIXES-EXPLAINED.md` in the package root for full details on each one.

The most common issues:

| Symptom | Likely fix # | What to do |
|---|---|---|
| `InvalidClientTokenId` | #10 | Re-paste AWS key from Notepad with single Ctrl+V |
| Build "succeeds" but app crashes | #8 | Make sure Dockerfile is at repo root |
| "Invalid Host header" in Copilot Studio | #1, #2, #3 | Wrapper missing DNS rebinding fix |
| Copilot Studio finds tools but doesn't call them | #19 | Set Generative orchestration |
