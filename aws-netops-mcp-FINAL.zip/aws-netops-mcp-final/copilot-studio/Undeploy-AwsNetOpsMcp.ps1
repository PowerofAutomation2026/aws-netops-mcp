# =============================================================================
# Undeploy-AwsNetOpsMcp.ps1
#
# Cleanly tears down the entire AWS NetOps MCP deployment from Azure.
# Deletes the resource group, which removes ALL resources inside it:
#   - Container App
#   - Container Apps Environment
#   - Azure Container Registry
#   - Log Analytics Workspace
#
# Usage:
#   .\Undeploy-AwsNetOpsMcp.ps1
#   .\Undeploy-AwsNetOpsMcp.ps1 -Force        # skip confirmation
# =============================================================================

[CmdletBinding()]
param(
    [string]$ResourceGroup = "rg-aws-netops-mcp",
    [switch]$Force
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════════════════╗" -ForegroundColor Red
Write-Host "║  AWS NetOps MCP — TEARDOWN                                         ║" -ForegroundColor Red
Write-Host "╚════════════════════════════════════════════════════════════════════╝" -ForegroundColor Red
Write-Host ""

# Verify Azure CLI is available
try {
    az version --output none 2>$null
} catch {
    Write-Host "  ✗ Azure CLI not found" -ForegroundColor Red
    exit 1
}

# Verify signed in
try {
    $sub = az account show --output json 2>$null | ConvertFrom-Json
    Write-Host "  Subscription: $($sub.name)" -ForegroundColor White
} catch {
    Write-Host "  ✗ Not signed in. Run: az login" -ForegroundColor Red
    exit 1
}

# Check resource group exists
$exists = az group exists --name $ResourceGroup
if ($exists -ne "true") {
    Write-Host "  ✓ Resource group '$ResourceGroup' does not exist — nothing to delete" -ForegroundColor Green
    exit 0
}

# Show what will be deleted
Write-Host ""
Write-Host "  This will DELETE the following resource group and ALL resources inside it:" -ForegroundColor Yellow
Write-Host ""
Write-Host "    Resource Group: $ResourceGroup" -ForegroundColor Yellow
Write-Host ""

$resources = az resource list --resource-group $ResourceGroup --query "[].{Name:name, Type:type}" -o json | ConvertFrom-Json
if ($resources.Count -gt 0) {
    Write-Host "  Resources that will be deleted:" -ForegroundColor Yellow
    foreach ($r in $resources) {
        Write-Host "    - $($r.Name) ($($r.Type))" -ForegroundColor Yellow
    }
    Write-Host ""
}

# Confirmation
if (-not $Force) {
    Write-Host "  This action is IRREVERSIBLE." -ForegroundColor Red
    $confirm = Read-Host "  Type the resource group name to confirm deletion"
    if ($confirm -ne $ResourceGroup) {
        Write-Host "  Aborted — confirmation did not match." -ForegroundColor Yellow
        exit 0
    }
}

# Delete
Write-Host ""
Write-Host "  Deleting resource group (this takes 2-5 minutes)..." -ForegroundColor White
az group delete --name $ResourceGroup --yes --no-wait

Write-Host ""
Write-Host "  ✓ Deletion initiated (running in background)" -ForegroundColor Green
Write-Host ""
Write-Host "  Check status:" -ForegroundColor White
Write-Host "    az group show --name $ResourceGroup" -ForegroundColor Gray
Write-Host ""
Write-Host "  Reminder — also clean up these manually if you no longer need them:" -ForegroundColor Yellow
Write-Host "    - Copilot Studio MCP entry (delete from Tools tab)" -ForegroundColor Yellow
Write-Host "    - AWS IAM access key (deactivate in IAM console)" -ForegroundColor Yellow
Write-Host "    - AWS IAM user 'netops-mcp' (delete in IAM console)" -ForegroundColor Yellow
Write-Host ""
