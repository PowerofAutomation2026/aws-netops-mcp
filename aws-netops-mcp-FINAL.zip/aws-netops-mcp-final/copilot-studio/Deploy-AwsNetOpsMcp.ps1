# ═════════════════════════════════════════════════════════════════════════════
#
#  Deploy-AwsNetOpsMcp.ps1
#  ───────────────────────
#  Bulletproof Azure Container Apps deployment for AWS NetOps MCP server.
#
#  This script bakes in EVERY ONE OF THE 21 FIXES from the deployment journey.
#  Each fix is referenced in comments below by its number (FIX #N).
#
#  ┌─────────────────────────────────────────────────────────────────────────┐
#  │  ALL 21 FIXES BAKED INTO THIS SCRIPT                                    │
#  ├─────────────────────────────────────────────────────────────────────────┤
#  │  1.  DNS rebinding protection disabled    → in aws_netops_mcp_http.py   │
#  │  2.  allowed_hosts = ["*"]                → in aws_netops_mcp_http.py   │
#  │  3.  allowed_origins = ["*"]              → in aws_netops_mcp_http.py   │
#  │  4.  stateless_http = True                → in aws_netops_mcp_http.py   │
#  │  5.  Uvicorn proxy_headers + forwarded_allow_ips                        │
#  │                                           → in aws_netops_mcp_http.py   │
#  │  6.  flush=True on print statements       → in aws_netops_mcp_http.py   │
#  │  7.  /health endpoint added               → in aws_netops_mcp_http.py   │
#  │  8.  Dockerfile at package root           → verified by STEP 1          │
#  │  9.  All COPY-target files at root        → verified by STEP 1          │
#  │  10. AWS key length verification (20/40)  → STEP 1                      │
#  │  11. No --output none flag                → STEP 7                      │
#  │  12. Env vars in separate update step     → STEP 8                      │
#  │  13. Zombie container detection/cleanup   → STEP 6                      │
#  │  14. Invoke-WebRequest, never curl        → STEP 9                      │
#  │  15. JSON-RPC initialize body for /mcp    → STEP 9                      │
#  │  16. Azure Portal Console (debugging)     → guidance in error messages  │
#  │  17. python -c live introspection         → guidance in error messages  │
#  │  18. python:slim limitations              → guidance in error messages  │
#  │  19. Generative orchestration             → printed in next-steps       │
#  │  20. Delete & re-add MCP entry            → printed in next-steps       │
#  │  21. 70-tool UI cap awareness             → printed in next-steps       │
#  └─────────────────────────────────────────────────────────────────────────┘
#
#  USAGE:
#    $env:AWS_ACCESS_KEY_ID = "AKIA..."
#    $env:AWS_SECRET_ACCESS_KEY = "..."
#    $env:AWS_DEFAULT_REGION = "us-east-1"
#    .\Deploy-AwsNetOpsMcp.ps1
#
#  OPTIONAL PARAMETERS:
#    -ResourceGroup    Override default rg-aws-netops-mcp
#    -Location         Override default eastus
#    -AppName          Override default aws-netops-mcp
#    -MinReplicas      0 = scale-to-zero. Default 1.
#    -MaxReplicas      Default 10
#    -Force            Skip confirmation prompt
#
# ═════════════════════════════════════════════════════════════════════════════

[CmdletBinding()]
param(
    [string]$ResourceGroup = "rg-aws-netops-mcp",
    [string]$Location = "eastus",
    [string]$AppName = "aws-netops-mcp",
    [string]$EnvironmentName = "aws-netops-mcp-env",
    [int]$MinReplicas = 1,
    [int]$MaxReplicas = 10,
    [switch]$Force
)

$ErrorActionPreference = "Stop"

# ─────────────────────────────────────────────────────────────────────────────
# Helper functions for nice output
# ─────────────────────────────────────────────────────────────────────────────

function Write-Header {
    param([string]$Text, [string]$FixRef = "")
    Write-Host ""
    Write-Host "════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    if ($FixRef) {
        Write-Host "  $Text" -ForegroundColor Cyan -NoNewline
        Write-Host "   [$FixRef]" -ForegroundColor DarkCyan
    } else {
        Write-Host "  $Text" -ForegroundColor Cyan
    }
    Write-Host "════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
}

function Write-Step { param([string]$Text)  Write-Host "  → $Text" -ForegroundColor White }
function Write-Ok   { param([string]$Text)  Write-Host "  ✓ $Text" -ForegroundColor Green }
function Write-Warn { param([string]$Text)  Write-Host "  ⚠ $Text" -ForegroundColor Yellow }
function Write-Err  { param([string]$Text)  Write-Host "  ✗ $Text" -ForegroundColor Red }
function Write-Hint { param([string]$Text)  Write-Host "    💡 $Text" -ForegroundColor DarkYellow }

function Fail {
    param([string]$Text, [string]$Hint = "")
    Write-Err "DEPLOYMENT FAILED: $Text"
    if ($Hint) { Write-Hint $Hint }
    exit 1
}

# ═════════════════════════════════════════════════════════════════════════════
# BANNER
# ═════════════════════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════════════════╗" -ForegroundColor Magenta
Write-Host "║  AWS NetOps MCP — Bulletproof Azure Container Apps Deployment      ║" -ForegroundColor Magenta
Write-Host "║  104 read-only AWS troubleshooting tools for Copilot Studio        ║" -ForegroundColor Magenta
Write-Host "║  All 21 deployment fixes baked in — should work first try          ║" -ForegroundColor Magenta
Write-Host "╚════════════════════════════════════════════════════════════════════╝" -ForegroundColor Magenta
Write-Host ""
Write-Host "  Configuration:" -ForegroundColor White
Write-Host "    Resource Group : $ResourceGroup"
Write-Host "    Location       : $Location"
Write-Host "    Container App  : $AppName"
Write-Host "    Environment    : $EnvironmentName"
Write-Host "    Replicas       : min=$MinReplicas, max=$MaxReplicas"
Write-Host "    Estimated cost : `$10-15/month (or <`$1/month if MinReplicas=0)"
Write-Host ""

if (-not $Force) {
    $confirm = Read-Host "  Proceed with deployment? (y/N)"
    if ($confirm -ne "y") {
        Write-Warn "Aborted by user"
        exit 0
    }
}

# ═════════════════════════════════════════════════════════════════════════════
# STEP 1 / 9 — PREREQUISITES
#   FIX #8 + #9: Verify Dockerfile and source files at package root
#   FIX #10:    Verify AWS key lengths to catch paste duplication
# ═════════════════════════════════════════════════════════════════════════════

Write-Header "STEP 1/9 — Prerequisites" "FIX #8, #9, #10"

# ─── Azure CLI installed ───
try {
    $azVersion = (az version --output json 2>$null | ConvertFrom-Json).'azure-cli'
    Write-Ok "Azure CLI installed: $azVersion"
} catch {
    Fail "Azure CLI not found" "Install: winget install Microsoft.AzureCLI"
}

# ─── Logged into Azure ───
try {
    $sub = az account show --output json 2>$null | ConvertFrom-Json
    Write-Ok "Signed in to Azure: $($sub.name)"
    Write-Host "    Subscription ID: $($sub.id)" -ForegroundColor Gray
} catch {
    Fail "Not signed in to Azure" "Run: az login"
}

# ─── FIX #8 + #9: Source files must be at package root, not subfolder ───
Write-Step "Verifying source files at package root (FIX #8, #9)..."
$requiredFiles = @(
    "aws_netops_mcp.py",
    "aws_netops_mcp_http.py",
    "Dockerfile",
    "requirements-http.txt"
)
foreach ($f in $requiredFiles) {
    if (-not (Test-Path $f)) {
        Fail "Missing required file at package root: $f" `
             "Run this script from the repo root, NOT from copilot-studio/. Cloud Build only finds Dockerfiles at root."
    }
}
Write-Ok "All source files present at package root"

# ─── FIX #10: AWS credentials with length verification ───
Write-Step "Verifying AWS credentials (FIX #10 — paste-duplication check)..."

if (-not $env:AWS_ACCESS_KEY_ID) {
    Fail "AWS_ACCESS_KEY_ID env var is not set" `
         '$env:AWS_ACCESS_KEY_ID = "AKIA..."'
}
if (-not $env:AWS_SECRET_ACCESS_KEY) {
    Fail "AWS_SECRET_ACCESS_KEY env var is not set" `
         '$env:AWS_SECRET_ACCESS_KEY = "..."'
}
if (-not $env:AWS_DEFAULT_REGION) {
    Write-Warn "AWS_DEFAULT_REGION not set — defaulting to us-east-1"
    $env:AWS_DEFAULT_REGION = "us-east-1"
}

$keyLen = $env:AWS_ACCESS_KEY_ID.Length
$secLen = $env:AWS_SECRET_ACCESS_KEY.Length
$keyPrefix = $env:AWS_ACCESS_KEY_ID.Substring(0, [Math]::Min(4, $keyLen))

if ($keyLen -ne 20) {
    Fail "AWS_ACCESS_KEY_ID is $keyLen chars (must be exactly 20)" `
         "PowerShell paste duplication. Open the CSV in Notepad, double-click the value to select, Ctrl+C, then paste exactly ONCE in PowerShell."
}
if ($secLen -ne 40) {
    Fail "AWS_SECRET_ACCESS_KEY is $secLen chars (must be exactly 40)" `
         "Same paste duplication. Use Notepad → double-click → Ctrl+C → single Ctrl+V."
}
if ($keyPrefix -ne "AKIA") {
    Write-Warn "Access Key ID doesn't start with AKIA — unusual but not always wrong"
}
Write-Ok "AWS credentials valid: AKIA*** (20 chars), secret (40 chars), region=$env:AWS_DEFAULT_REGION"

# ═════════════════════════════════════════════════════════════════════════════
# STEP 2 / 9 — CONTAINER APPS CLI EXTENSION
# ═════════════════════════════════════════════════════════════════════════════

Write-Header "STEP 2/9 — Container Apps CLI extension"

$ext = az extension list --query "[?name=='containerapp']" --output json | ConvertFrom-Json
if ($ext.Count -eq 0) {
    Write-Step "Installing containerapp extension..."
    az extension add --name containerapp --upgrade --only-show-errors | Out-Null
    Write-Ok "Extension installed"
} else {
    Write-Step "Updating containerapp extension to latest..."
    az extension update --name containerapp --only-show-errors 2>$null | Out-Null
    Write-Ok "Extension up to date"
}

# ═════════════════════════════════════════════════════════════════════════════
# STEP 3 / 9 — REGISTER AZURE RESOURCE PROVIDERS
# ═════════════════════════════════════════════════════════════════════════════

Write-Header "STEP 3/9 — Azure resource providers"

$providers = @(
    "Microsoft.App",
    "Microsoft.OperationalInsights",
    "Microsoft.ContainerRegistry"
)
foreach ($p in $providers) {
    $state = az provider show --namespace $p --query registrationState -o tsv 2>$null
    if ($state -eq "Registered") {
        Write-Ok "$p — already registered"
    } else {
        Write-Step "Registering $p..."
        az provider register --namespace $p --only-show-errors | Out-Null
        Write-Ok "$p — registered"
    }
}

# ═════════════════════════════════════════════════════════════════════════════
# STEP 4 / 9 — RESOURCE GROUP
# ═════════════════════════════════════════════════════════════════════════════

Write-Header "STEP 4/9 — Resource group"

$rgExists = az group exists --name $ResourceGroup
if ($rgExists -eq "true") {
    Write-Ok "Resource group '$ResourceGroup' already exists"
} else {
    Write-Step "Creating '$ResourceGroup' in $Location..."
    az group create --name $ResourceGroup --location $Location --output none
    Write-Ok "Resource group created"
}

# ═════════════════════════════════════════════════════════════════════════════
# STEP 5 / 9 — CONTAINER APPS ENVIRONMENT (slowest step ~2 min)
# ═════════════════════════════════════════════════════════════════════════════

Write-Header "STEP 5/9 — Container Apps environment (~2 minutes)"

$envExists = az containerapp env show --name $EnvironmentName --resource-group $ResourceGroup --output json 2>$null
if ($envExists) {
    Write-Ok "Environment '$EnvironmentName' already exists"
} else {
    Write-Step "Creating environment (this is the slowest step)..."
    az containerapp env create `
        --name $EnvironmentName `
        --resource-group $ResourceGroup `
        --location $Location `
        --only-show-errors | Out-Null
    Write-Ok "Environment created"
}

# ═════════════════════════════════════════════════════════════════════════════
# STEP 6 / 9 — ZOMBIE CONTAINER CHECK
#   FIX #13: Detect and clean up zombie containers from failed deploys
# ═════════════════════════════════════════════════════════════════════════════

Write-Header "STEP 6/9 — Zombie container check" "FIX #13"

$existingApp = az containerapp show --name $AppName --resource-group $ResourceGroup --output json 2>$null
if ($existingApp) {
    $appData = $existingApp | ConvertFrom-Json
    $containerCount = $appData.properties.template.containers.Count

    if ($containerCount -gt 1) {
        Write-Warn "Detected $containerCount containers in same revision (zombie from previous failed deploy)"
        Write-Step "Deleting Container App for clean slate..."
        az containerapp delete --name $AppName --resource-group $ResourceGroup --yes --only-show-errors | Out-Null
        Write-Ok "Zombie cleaned up"
    } else {
        Write-Ok "No zombie containers detected (existing app is clean)"
    }
} else {
    Write-Ok "Fresh deploy — no existing app"
}

# ═════════════════════════════════════════════════════════════════════════════
# STEP 7 / 9 — BUILD & DEPLOY CONTAINER (~5 min)
#   FIX #11: Do NOT pass --output none (not supported by containerapp up)
#   FIX #12: Do NOT pass --env-vars here (PowerShell expansion unreliable)
# ═════════════════════════════════════════════════════════════════════════════

Write-Header "STEP 7/9 — Build & deploy container (~5 minutes)" "FIX #11, #12"

Write-Step "Azure ACR will build the Docker image — no Docker needed locally"
Write-Step "Source files at root (FIX #8) → Cloud Build will use Dockerfile correctly"
Write-Step "Skipping --env-vars here (FIX #12) — applying them in next step"

# IMPORTANT: do NOT pass --output none. Not supported on this subcommand (FIX #11)
# IMPORTANT: do NOT pass --env-vars. Apply separately in next step (FIX #12)
$deployResult = az containerapp up `
    --name $AppName `
    --resource-group $ResourceGroup `
    --environment $EnvironmentName `
    --source . `
    --target-port 8000 `
    --ingress external `
    --location $Location 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Err "az containerapp up failed"
    Write-Host $deployResult -ForegroundColor Red
    Write-Hint "Common causes:"
    Write-Hint "  - Dockerfile syntax error"
    Write-Hint "  - ACR quota exceeded"
    Write-Hint "  - Build timeout (rare)"
    Fail "Build/deploy failed" "Check the output above"
}
Write-Ok "Container deployed"

# ═════════════════════════════════════════════════════════════════════════════
# STEP 8 / 9 — APPLY ENV VARS (separate step for reliability)
#   FIX #12: PowerShell $env: expansion unreliable on `containerapp create`
# ═════════════════════════════════════════════════════════════════════════════

Write-Header "STEP 8/9 — Inject AWS credentials" "FIX #12"

Write-Step "Using --set-env-vars on update (more reliable than --env-vars on create)"
az containerapp update `
    --name $AppName `
    --resource-group $ResourceGroup `
    --set-env-vars `
        "AWS_ACCESS_KEY_ID=$env:AWS_ACCESS_KEY_ID" `
        "AWS_SECRET_ACCESS_KEY=$env:AWS_SECRET_ACCESS_KEY" `
        "AWS_DEFAULT_REGION=$env:AWS_DEFAULT_REGION" `
    --only-show-errors | Out-Null

Write-Ok "AWS credentials injected"

# Configure auto-scaling
Write-Step "Configuring auto-scaling (min=$MinReplicas, max=$MaxReplicas)..."
az containerapp update `
    --name $AppName `
    --resource-group $ResourceGroup `
    --min-replicas $MinReplicas `
    --max-replicas $MaxReplicas `
    --only-show-errors | Out-Null
Write-Ok "Auto-scaling configured"

# ═════════════════════════════════════════════════════════════════════════════
# STEP 9 / 9 — VERIFY DEPLOYMENT
#   FIX #14: Use Invoke-WebRequest, never curl in PowerShell
#   FIX #15: Test /mcp with proper JSON-RPC initialize body
# ═════════════════════════════════════════════════════════════════════════════

Write-Header "STEP 9/9 — Verify deployment" "FIX #14, #15"

$fqdn = az containerapp show `
    --name $AppName `
    --resource-group $ResourceGroup `
    --query properties.configuration.ingress.fqdn -o tsv

if (-not $fqdn) {
    Fail "Could not retrieve FQDN" "Check the app in Azure Portal manually"
}

$baseUrl = "https://$fqdn"
Write-Ok "Container app URL: $baseUrl"

Write-Step "Waiting 45s for container to fully start (loading 104 tools takes time)..."
Start-Sleep -Seconds 45

# ─── TEST 1: /health endpoint ───
Write-Step "Testing /health endpoint..."
$healthOk = $false
for ($i = 1; $i -le 5; $i++) {
    try {
        # FIX #14: Use Invoke-WebRequest, never curl
        $health = Invoke-WebRequest `
            -Uri "$baseUrl/health" `
            -UseBasicParsing `
            -TimeoutSec 30 `
            -ErrorAction Stop

        if ($health.StatusCode -eq 200) {
            $healthData = $health.Content | ConvertFrom-Json
            Write-Ok "Health OK — status=$($healthData.status), tools=$($healthData.tools)"
            $healthOk = $true
            break
        }
    } catch {
        Write-Step "Attempt $i/5 failed, retrying in 15s..."
        Start-Sleep -Seconds 15
    }
}

if (-not $healthOk) {
    Write-Warn "Health endpoint did not respond after 5 attempts"
    Write-Hint "Check logs: az containerapp logs show -n $AppName -g $ResourceGroup --tail 50"
    Write-Hint "Or use Azure Portal Console (FIX #16) for live debugging"
    exit 1
}

# ─── TEST 2: MCP /mcp endpoint with proper JSON-RPC initialize ───
# FIX #15: Test with the exact handshake Copilot Studio sends
Write-Step "Testing /mcp endpoint with MCP initialize handshake (FIX #15)..."

try {
    $mcpBody = '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"deploy-script","version":"1.0"}}}'

    # FIX #14 again: Invoke-WebRequest, never curl
    $mcpResponse = Invoke-WebRequest `
        -Uri "$baseUrl/mcp" `
        -Method POST `
        -ContentType "application/json" `
        -Headers @{"Accept"="application/json, text/event-stream"} `
        -Body $mcpBody `
        -UseBasicParsing `
        -TimeoutSec 30 `
        -ErrorAction Stop

    if ($mcpResponse.Content -match "serverInfo") {
        Write-Ok "MCP endpoint responds correctly with serverInfo"
        Write-Ok "All 21 fixes verified working — deployment is production-ready"
    } else {
        $sample = $mcpResponse.Content.Substring(0, [Math]::Min(200, $mcpResponse.Content.Length))
        Write-Warn "MCP returned unexpected response: $sample"
    }
} catch {
    if ($_.Exception.Message -match "Invalid Host header") {
        # FIX #1, #2, #3: DNS rebinding protection issue
        Write-Err "Invalid Host header — your aws_netops_mcp_http.py is missing FIX #1-3"
        Write-Hint "These 3 lines must be in aws_netops_mcp_http.py BEFORE streamable_http_app():"
        Write-Host '    core.mcp.settings.transport_security.enable_dns_rebinding_protection = False' -ForegroundColor Yellow
        Write-Host '    core.mcp.settings.transport_security.allowed_hosts = ["*"]' -ForegroundColor Yellow
        Write-Host '    core.mcp.settings.transport_security.allowed_origins = ["*"]' -ForegroundColor Yellow
        Write-Host ""
        Write-Hint "Verify with FIX #16+#17 (Azure Portal Console + python -c):"
        Write-Host '    python -c "from mcp.server.fastmcp import FastMCP; m=FastMCP(\"x\"); print(m.settings.transport_security)"' -ForegroundColor Yellow
    } else {
        Write-Warn "MCP test failed: $($_.Exception.Message)"
    }
}

# ═════════════════════════════════════════════════════════════════════════════
# DEPLOYMENT COMPLETE — NEXT STEPS
#   FIX #19: Tell user to set Generative orchestration
#   FIX #20: Tell user to delete & re-add MCP entry if there's an issue
#   FIX #21: Inform user about the 70-tool UI display cap
# ═════════════════════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  ✓ DEPLOYMENT COMPLETE — All 21 fixes applied                      ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "  Your MCP server is live at:" -ForegroundColor White
Write-Host ""
Write-Host "    $baseUrl/mcp" -ForegroundColor Cyan -NoNewline
Write-Host "  ← paste this into Copilot Studio" -ForegroundColor Gray
Write-Host ""
Write-Host "  Health check:" -ForegroundColor White
Write-Host "    Invoke-WebRequest $baseUrl/health" -ForegroundColor Gray
Write-Host ""
Write-Host "  Stream live logs:" -ForegroundColor White
Write-Host "    az containerapp logs show -n $AppName -g $ResourceGroup --follow" -ForegroundColor Gray
Write-Host ""

Write-Host "  ──────────────────────────────────────────────────────────────────" -ForegroundColor Gray
Write-Host "  NEXT STEPS — Connect Copilot Studio  [FIX #19, #20, #21]" -ForegroundColor White
Write-Host "  ──────────────────────────────────────────────────────────────────" -ForegroundColor Gray
Write-Host ""
Write-Host "    1. Open " -NoNewline; Write-Host "https://copilotstudio.microsoft.com" -ForegroundColor Cyan
Write-Host "    2. Open or create your agent"
Write-Host ""
Write-Host "    3. " -NoNewline; Write-Host "[FIX #19] CRITICAL:" -ForegroundColor Yellow -NoNewline
Write-Host " Settings → Generative AI → Orchestration = " -NoNewline
Write-Host "Generative" -ForegroundColor Green -NoNewline
Write-Host " (NOT Classic)"
Write-Host "       Without this, the AI won't actually call your tools."
Write-Host ""
Write-Host "    4. Tools → + Add a tool → New tool → Model Context Protocol"
Write-Host ""
Write-Host "    5. Server URL:    " -NoNewline
Write-Host "$baseUrl/mcp" -ForegroundColor Cyan
Write-Host "       Authentication: None"
Write-Host ""
Write-Host "    6. Click Create → should show 'Discovered 104 tools'"
Write-Host ""
Write-Host "    7. " -NoNewline; Write-Host "[FIX #21] Note:" -ForegroundColor Yellow -NoNewline
Write-Host " Copilot Studio's UI caps display at 70 tools, but"
Write-Host "       all 104 are still callable. This is cosmetic, not a bug."
Write-Host ""
Write-Host "    8. " -NoNewline; Write-Host "[FIX #20] If 'Connector request failed':" -ForegroundColor Yellow
Write-Host "       Don't click Refresh — DELETE the MCP entry, then re-add it."
Write-Host ""
Write-Host "    9. Test with:  " -NoNewline; Write-Host '"Who am I in AWS?"' -ForegroundColor Green
Write-Host ""
Write-Host "  ──────────────────────────────────────────────────────────────────" -ForegroundColor Gray
Write-Host "  Estimated monthly cost:" -ForegroundColor White -NoNewline
Write-Host " ~`$10-15 (always-on)" -ForegroundColor Green
Write-Host "                          " -NoNewline
Write-Host " <`$1 (if -MinReplicas 0, scale to zero)" -ForegroundColor Green
Write-Host ""
Write-Host "  Need to tear down? Run: " -NoNewline -ForegroundColor White
Write-Host ".\Undeploy-AwsNetOpsMcp.ps1" -ForegroundColor Cyan
Write-Host ""
