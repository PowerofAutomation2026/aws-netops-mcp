# =============================================================================
# Test-AwsNetOpsMcp.ps1
#
# Verifies the deployed MCP server is healthy and responding correctly.
# Run this anytime to confirm the deployment is still working.
#
# Usage:
#   .\Test-AwsNetOpsMcp.ps1
# =============================================================================

[CmdletBinding()]
param(
    [string]$ResourceGroup = "rg-aws-netops-mcp",
    [string]$AppName = "aws-netops-mcp"
)

$ErrorActionPreference = "Continue"

Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  AWS NetOps MCP — Deployment Test Suite                            ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

$pass = 0
$fail = 0

function Test-Result {
    param([bool]$Ok, [string]$Name, [string]$Detail = "")
    if ($Ok) {
        Write-Host "  ✓ $Name" -ForegroundColor Green
        if ($Detail) { Write-Host "    $Detail" -ForegroundColor Gray }
        $script:pass++
    } else {
        Write-Host "  ✗ $Name" -ForegroundColor Red
        if ($Detail) { Write-Host "    $Detail" -ForegroundColor Yellow }
        $script:fail++
    }
}

# Test 1 — Container app exists and is running
Write-Host "Test 1: Container app status" -ForegroundColor White
try {
    $status = az containerapp show --name $AppName --resource-group $ResourceGroup --query "properties.runningStatus" -o tsv 2>$null
    Test-Result ($status -eq "Running") "Container app is Running" "Status: $status"
} catch {
    Test-Result $false "Container app is Running" "Could not query container app — does it exist?"
    exit 1
}

# Test 2 — Get FQDN
Write-Host ""
Write-Host "Test 2: Public FQDN" -ForegroundColor White
$fqdn = az containerapp show --name $AppName --resource-group $ResourceGroup --query "properties.configuration.ingress.fqdn" -o tsv 2>$null
$baseUrl = "https://$fqdn"
Test-Result ($null -ne $fqdn -and $fqdn.Length -gt 0) "FQDN retrieved" $baseUrl

# Test 3 — Health endpoint
Write-Host ""
Write-Host "Test 3: /health endpoint" -ForegroundColor White
try {
    $health = Invoke-WebRequest -Uri "$baseUrl/health" -UseBasicParsing -TimeoutSec 30
    $data = $health.Content | ConvertFrom-Json
    Test-Result ($data.status -eq "ok") "Health endpoint OK" "Tools loaded: $($data.tools)"
} catch {
    Test-Result $false "Health endpoint" $_.Exception.Message
}

# Test 4 — MCP initialize handshake (tests Cliff #4 fix)
Write-Host ""
Write-Host "Test 4: MCP /mcp endpoint (JSON-RPC initialize)" -ForegroundColor White
try {
    $body = '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}'
    $resp = Invoke-WebRequest `
        -Uri "$baseUrl/mcp" `
        -Method POST `
        -ContentType "application/json" `
        -Headers @{"Accept"="application/json, text/event-stream"} `
        -Body $body `
        -UseBasicParsing -TimeoutSec 30

    if ($resp.Content -match "serverInfo") {
        Test-Result $true "MCP initialize returned serverInfo"
    } else {
        Test-Result $false "MCP initialize" "Got response but no serverInfo: $($resp.Content.Substring(0, [Math]::Min(100, $resp.Content.Length)))"
    }
} catch {
    if ($_.Exception.Message -match "Invalid Host header") {
        Test-Result $false "MCP initialize" "Invalid Host header — DNS rebinding fix missing in aws_netops_mcp_http.py"
    } else {
        Test-Result $false "MCP initialize" $_.Exception.Message
    }
}

# Summary
Write-Host ""
Write-Host "════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
if ($fail -eq 0) {
    Write-Host "  ✓ ALL TESTS PASSED ($pass/$($pass+$fail))" -ForegroundColor Green
    Write-Host ""
    Write-Host "  MCP endpoint is ready for Copilot Studio:" -ForegroundColor White
    Write-Host "    $baseUrl/mcp" -ForegroundColor Cyan
} else {
    Write-Host "  ✗ TESTS FAILED ($fail failed, $pass passed)" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Check container logs:" -ForegroundColor Yellow
    Write-Host "    az containerapp logs show --name $AppName --resource-group $ResourceGroup --tail 50"
}
Write-Host "════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
