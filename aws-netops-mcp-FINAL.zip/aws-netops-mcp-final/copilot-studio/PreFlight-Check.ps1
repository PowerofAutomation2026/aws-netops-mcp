# ═════════════════════════════════════════════════════════════════════════════
#
#  PreFlight-Check.ps1
#  ───────────────────
#  Run this BEFORE Deploy-AwsNetOpsMcp.ps1 to verify all 21 fixes are in place.
#
#  Catches problems in 30 seconds instead of 10 minutes into a failed deploy.
#
#  USAGE:
#    .\PreFlight-Check.ps1
#
# ═════════════════════════════════════════════════════════════════════════════

[CmdletBinding()]
param()

$ErrorActionPreference = "Continue"
$pass = 0
$fail = 0
$warn = 0

function Check {
    param([bool]$Result, [string]$Name, [string]$FixRef = "", [string]$Detail = "")
    if ($Result) {
        Write-Host "  ✓ " -ForegroundColor Green -NoNewline
        Write-Host "$Name" -NoNewline
        if ($FixRef) { Write-Host "  [$FixRef]" -ForegroundColor DarkGray } else { Write-Host "" }
        $script:pass++
    } else {
        Write-Host "  ✗ " -ForegroundColor Red -NoNewline
        Write-Host "$Name" -NoNewline
        if ($FixRef) { Write-Host "  [$FixRef]" -ForegroundColor DarkGray } else { Write-Host "" }
        if ($Detail) { Write-Host "    → $Detail" -ForegroundColor Yellow }
        $script:fail++
    }
}

function CheckWarn {
    param([bool]$Result, [string]$Name, [string]$Detail = "")
    if ($Result) {
        Write-Host "  ✓ $Name" -ForegroundColor Green
        $script:pass++
    } else {
        Write-Host "  ⚠ $Name" -ForegroundColor Yellow
        if ($Detail) { Write-Host "    → $Detail" -ForegroundColor DarkYellow }
        $script:warn++
    }
}

Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  AWS NetOps MCP — Pre-Flight Check                                 ║" -ForegroundColor Cyan
Write-Host "║  Verifies all 21 fixes are in place before deployment              ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# ─────────────────────────────────────────────────────────────────────────────
# Section 1: Source files at package root (FIX #8, #9)
# ─────────────────────────────────────────────────────────────────────────────

Write-Host "🐳 BUILD & PACKAGING (FIX #8, #9)" -ForegroundColor Magenta
Write-Host "──────────────────────────────────"

Check (Test-Path "Dockerfile") "Dockerfile at package root" "FIX #8" `
      "Move Dockerfile to repo root, NOT in copilot-studio/ subfolder"
Check (Test-Path "aws_netops_mcp.py") "aws_netops_mcp.py at root" "FIX #9"
Check (Test-Path "aws_netops_mcp_http.py") "aws_netops_mcp_http.py at root" "FIX #9"
Check (Test-Path "requirements-http.txt") "requirements-http.txt at root" "FIX #9"

# ─────────────────────────────────────────────────────────────────────────────
# Section 2: HTTP wrapper has all 7 critical fixes (FIX #1-7)
# ─────────────────────────────────────────────────────────────────────────────

Write-Host ""
Write-Host "🐍 PYTHON WRAPPER FIXES (FIX #1-7)" -ForegroundColor Magenta
Write-Host "──────────────────────────────────"

if (Test-Path "aws_netops_mcp_http.py") {
    $content = Get-Content "aws_netops_mcp_http.py" -Raw

    Check ($content -match "enable_dns_rebinding_protection\s*=\s*False") `
          "FIX #1 — enable_dns_rebinding_protection = False" "CRITICAL" `
          "Add: core.mcp.settings.transport_security.enable_dns_rebinding_protection = False"

    Check ($content -match 'allowed_hosts\s*=\s*\[\s*"\*"\s*\]') `
          "FIX #2 — allowed_hosts = [`"*`"]" "CRITICAL" `
          'Add: core.mcp.settings.transport_security.allowed_hosts = ["*"]'

    Check ($content -match 'allowed_origins\s*=\s*\[\s*"\*"\s*\]') `
          "FIX #3 — allowed_origins = [`"*`"]" "CRITICAL" `
          'Add: core.mcp.settings.transport_security.allowed_origins = ["*"]'

    Check ($content -match "stateless_http\s*=\s*True") `
          "FIX #4 — stateless_http = True" "CRITICAL" `
          "Add: core.mcp.settings.stateless_http = True"

    Check ($content -match 'forwarded_allow_ips\s*=\s*"\*"') `
          "FIX #5 — Uvicorn forwarded_allow_ips" "CRITICAL" `
          'Add to uvicorn.run: forwarded_allow_ips="*", proxy_headers=True'

    Check ($content -match "proxy_headers\s*=\s*True") `
          "FIX #5b — Uvicorn proxy_headers = True" "CRITICAL" `
          "Add: proxy_headers=True to uvicorn.run()"

    CheckWarn ($content -match "flush\s*=\s*True") `
          "FIX #6 — flush=True on print statements" `
          "Add flush=True to print() calls for immediate log output"

    Check ($content -match "Route\s*\(\s*[`"']/health[`"']") `
          "FIX #7 — /health endpoint" "CRITICAL" `
          "Add: app.routes.append(Route('/health', health, methods=['GET']))"
} else {
    Write-Host "  ✗ Cannot check wrapper — file missing" -ForegroundColor Red
    $fail += 7
}

# ─────────────────────────────────────────────────────────────────────────────
# Section 3: AWS credentials (FIX #10)
# ─────────────────────────────────────────────────────────────────────────────

Write-Host ""
Write-Host "🔑 AWS CREDENTIALS (FIX #10)" -ForegroundColor Magenta
Write-Host "──────────────────────────────────"

$keySet = $null -ne $env:AWS_ACCESS_KEY_ID -and $env:AWS_ACCESS_KEY_ID.Length -gt 0
$secSet = $null -ne $env:AWS_SECRET_ACCESS_KEY -and $env:AWS_SECRET_ACCESS_KEY.Length -gt 0
$regSet = $null -ne $env:AWS_DEFAULT_REGION -and $env:AWS_DEFAULT_REGION.Length -gt 0

Check $keySet "AWS_ACCESS_KEY_ID env var is set" "FIX #10" `
      'Run: $env:AWS_ACCESS_KEY_ID = "AKIA..."'
Check $secSet "AWS_SECRET_ACCESS_KEY env var is set" "FIX #10" `
      'Run: $env:AWS_SECRET_ACCESS_KEY = "..."'
CheckWarn $regSet "AWS_DEFAULT_REGION env var is set" `
      'Recommended: $env:AWS_DEFAULT_REGION = "us-east-1"'

if ($keySet) {
    $keyLen = $env:AWS_ACCESS_KEY_ID.Length
    Check ($keyLen -eq 20) "Access Key ID is exactly 20 chars (currently: $keyLen)" "FIX #10" `
          "PowerShell paste duplication! Re-paste from Notepad with single Ctrl+V."
    Check ($env:AWS_ACCESS_KEY_ID.StartsWith("AKIA")) "Access Key ID starts with AKIA" "FIX #10" `
          "Check you copied the right value — AWS access keys begin with AKIA"
}
if ($secSet) {
    $secLen = $env:AWS_SECRET_ACCESS_KEY.Length
    Check ($secLen -eq 40) "Secret Access Key is exactly 40 chars (currently: $secLen)" "FIX #10" `
          "PowerShell paste duplication! Re-paste from Notepad with single Ctrl+V."
}

# ─────────────────────────────────────────────────────────────────────────────
# Section 4: Azure CLI prerequisites
# ─────────────────────────────────────────────────────────────────────────────

Write-Host ""
Write-Host "☁️  AZURE PREREQUISITES" -ForegroundColor Magenta
Write-Host "──────────────────────────────────"

try {
    $azVersion = (az version --output json 2>$null | ConvertFrom-Json).'azure-cli'
    Check $true "Azure CLI installed (v$azVersion)"
} catch {
    Check $false "Azure CLI installed" "" "Install: winget install Microsoft.AzureCLI"
}

try {
    $sub = az account show --output json 2>$null | ConvertFrom-Json
    Check $true "Signed in to Azure: $($sub.name)"
} catch {
    Check $false "Signed in to Azure" "" "Run: az login"
}

try {
    $ext = az extension list --query "[?name=='containerapp']" --output json 2>$null | ConvertFrom-Json
    CheckWarn ($ext.Count -gt 0) "containerapp CLI extension installed" `
              "Will be installed automatically by Deploy script"
} catch {
    Write-Warn "Couldn't check extensions"
}

# ─────────────────────────────────────────────────────────────────────────────
# Section 5: Optional AWS credential validation
# ─────────────────────────────────────────────────────────────────────────────

Write-Host ""
Write-Host "🌍 AWS CONNECTIVITY (optional but recommended)" -ForegroundColor Magenta
Write-Host "──────────────────────────────────"

if ($keySet -and $secSet) {
    try {
        $awsTest = aws sts get-caller-identity --output json 2>$null | ConvertFrom-Json
        if ($awsTest.Account) {
            Check $true "AWS credentials work — account $($awsTest.Account)"
            Write-Host "    User: $($awsTest.Arn)" -ForegroundColor Gray
        }
    } catch {
        CheckWarn $false "Couldn't verify AWS credentials with sts:GetCallerIdentity" `
                  "AWS CLI not installed locally, OR credentials are wrong. Deploy script will catch this anyway."
    }
} else {
    Write-Host "  ⏭ Skipped — credentials not set" -ForegroundColor DarkGray
}

# ─────────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────────

Write-Host ""
Write-Host "════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan

if ($fail -eq 0) {
    Write-Host "  ✓ ALL CRITICAL CHECKS PASSED ($pass passed, $warn warnings)" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Ready to deploy. Run:" -ForegroundColor White
    Write-Host "    .\Deploy-AwsNetOpsMcp.ps1" -ForegroundColor Cyan
} else {
    Write-Host "  ✗ PRE-FLIGHT FAILED ($fail critical, $warn warnings, $pass passed)" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Fix the issues above, then re-run this script." -ForegroundColor Yellow
    Write-Host "  Common fixes:" -ForegroundColor White
    Write-Host "    - Move Dockerfile to repo root (FIX #8)" -ForegroundColor Gray
    Write-Host "    - Re-paste AWS keys from Notepad with single Ctrl+V (FIX #10)" -ForegroundColor Gray
    Write-Host "    - Update aws_netops_mcp_http.py with all 7 wrapper fixes" -ForegroundColor Gray
    exit 1
}
Write-Host "════════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
