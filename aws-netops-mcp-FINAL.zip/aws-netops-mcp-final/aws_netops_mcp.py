"""
AWS NetOps MCP — 104 read-only AWS troubleshooting tools for AI agents.

Works with:
  - Claude Desktop (via stdio, this file directly)
  - Microsoft Copilot Studio (via aws_netops_mcp_http.py wrapper)
  - GitHub Copilot, Cursor, ChatGPT Desktop, any MCP client

Run locally for Claude Desktop:
    pip install -r requirements.txt
    python aws_netops_mcp.py

Then add to claude_desktop_config.json:
    {
      "mcpServers": {
        "aws-netops": {
          "command": "python",
          "args": ["/path/to/aws_netops_mcp.py"],
          "env": {
            "AWS_PROFILE": "netops",
            "AWS_DEFAULT_REGION": "us-east-1"
          }
        }
      }
    }

Security model:
  - Every tool is READ-ONLY (no creates, updates, or deletes)
  - IAM user must have ONLY the AWS-managed ReadOnlyAccess policy
  - Credentials come from AWS_PROFILE or AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY
"""
import json
import os
from datetime import datetime, timezone, timedelta
from typing import Optional

import boto3
from botocore.exceptions import ClientError
from mcp.server.fastmcp import FastMCP

# ─────────────────────────────────────────────────────────────────────────────
# Setup
# ─────────────────────────────────────────────────────────────────────────────

mcp = FastMCP("aws-netops")

# Use AWS_PROFILE if set, else fall back to env vars / IAM role
PROFILE = os.environ.get("AWS_PROFILE")
REGION = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")


def _session():
    """Build a boto3 session that works in both Claude Desktop (profile) and
    Container Apps (env vars)."""
    if PROFILE:
        return boto3.Session(profile_name=PROFILE, region_name=REGION)
    return boto3.Session(region_name=REGION)


def _client(service: str, region: Optional[str] = None):
    return _session().client(service, region_name=region or REGION)


def _safe(fn):
    """Wrap a tool so AWS errors return readable JSON instead of crashing."""
    def wrapper(*args, **kwargs):
        try:
            result = fn(*args, **kwargs)
            return _serialize(result)
        except ClientError as e:
            return {
                "error": e.response["Error"]["Code"],
                "message": e.response["Error"]["Message"],
                "tool": fn.__name__,
            }
        except Exception as e:
            return {"error": type(e).__name__, "message": str(e), "tool": fn.__name__}
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


def _serialize(obj):
    """Convert datetime objects to ISO strings so JSON serialization works."""
    if isinstance(obj, dict):
        return {k: _serialize(v) for k, v in obj.items() if k != "ResponseMetadata"}
    if isinstance(obj, list):
        return [_serialize(x) for x in obj]
    if isinstance(obj, datetime):
        return obj.isoformat()
    return obj


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 1: IDENTITY (3 tools)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def whoami() -> dict:
    """Return the IAM identity these tools are running as. Use this first
    if anything looks wrong — confirms which AWS account is being queried."""
    return _safe(lambda: _client("sts").get_caller_identity())()


@mcp.tool()
def get_user_policies(user_name: str) -> dict:
    """List managed + inline policies attached to an IAM user. Useful for
    debugging 'why is this user being denied?' incidents.

    Args:
        user_name: IAM user name, e.g. 'app-deploy-user'.
    """
    iam = _client("iam")
    @_safe
    def _():
        managed = iam.list_attached_user_policies(UserName=user_name)
        inline = iam.list_user_policies(UserName=user_name)
        return {"managed": managed.get("AttachedPolicies"), "inline": inline.get("PolicyNames")}
    return _()


@mcp.tool()
def simulate_principal_policy(principal_arn: str, action_names: list[str], resource_arns: list[str]) -> dict:
    """Use IAM Policy Simulator to check whether a principal can perform
    actions, including conditional-access checks like aws:SourceIp.

    Args:
        principal_arn: ARN of the user or role to test.
        action_names: List of IAM actions, e.g. ['s3:GetObject', 'ec2:DescribeInstances'].
        resource_arns: List of resource ARNs to test against.
    """
    @_safe
    def _():
        return _client("iam").simulate_principal_policy(
            PolicySourceArn=principal_arn,
            ActionNames=action_names,
            ResourceArns=resource_arns,
        )
    return _()


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 2: VPC / NETWORKING (5 tools)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def list_vpcs() -> dict:
    """List every VPC in the current Region with CIDR, state, Name tag."""
    @_safe
    def _():
        vpcs = _client("ec2").describe_vpcs().get("Vpcs", [])
        return [{
            "VpcId": v["VpcId"],
            "CidrBlock": v["CidrBlock"],
            "State": v["State"],
            "IsDefault": v["IsDefault"],
            "Name": next((t["Value"] for t in v.get("Tags", []) if t["Key"] == "Name"), None),
        } for v in vpcs]
    return _()


@mcp.tool()
def describe_subnets(vpc_id: str) -> dict:
    """List subnets in a VPC with AZ, CIDR, free-IP count.

    Args:
        vpc_id: The VPC id, e.g. 'vpc-0abc1234'.
    """
    @_safe
    def _():
        subnets = _client("ec2").describe_subnets(
            Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
        ).get("Subnets", [])
        return [{
            "SubnetId": s["SubnetId"],
            "AvailabilityZone": s["AvailabilityZone"],
            "CidrBlock": s["CidrBlock"],
            "AvailableIpAddressCount": s["AvailableIpAddressCount"],
            "MapPublicIpOnLaunch": s["MapPublicIpOnLaunch"],
        } for s in subnets]
    return _()


@mcp.tool()
def describe_route_tables(vpc_id: str) -> dict:
    """Show every route table in a VPC and its routes/associations.
    Use when traffic isn't flowing as expected.

    Args:
        vpc_id: The VPC id, e.g. 'vpc-0abc1234'.
    """
    @_safe
    def _():
        return _client("ec2").describe_route_tables(
            Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
        )
    return _()


@mcp.tool()
def describe_nacls(vpc_id: str) -> dict:
    """List Network ACLs (subnet-level stateless firewall) in a VPC.

    Args:
        vpc_id: The VPC id, e.g. 'vpc-0abc1234'.
    """
    @_safe
    def _():
        return _client("ec2").describe_network_acls(
            Filters=[{"Name": "vpc-id", "Values": [vpc_id]}]
        )
    return _()


@mcp.tool()
def describe_vpc_endpoints(vpc_id: Optional[str] = None) -> dict:
    """List VPC endpoints (PrivateLink interfaces and gateway endpoints).
    Useful for diagnosing 'can't reach S3/DynamoDB privately' issues.

    Args:
        vpc_id: Optional VPC id to filter by.
    """
    @_safe
    def _():
        kw = {}
        if vpc_id:
            kw["Filters"] = [{"Name": "vpc-id", "Values": [vpc_id]}]
        return _client("ec2").describe_vpc_endpoints(**kw)
    return _()


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 3: SECURITY GROUPS (2 tools)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def describe_security_group(group_id: str) -> dict:
    """Get full ingress/egress rules for a Security Group.

    Args:
        group_id: SG id, e.g. 'sg-0abcd1234'.
    """
    @_safe
    def _():
        result = _client("ec2").describe_security_groups(GroupIds=[group_id])
        return result.get("SecurityGroups", [])
    return _()


@mcp.tool()
def find_sg_by_name(name_substring: str) -> dict:
    """Search Security Groups whose name or Name-tag contains a substring.

    Args:
        name_substring: Substring to search for, case-insensitive.
    """
    @_safe
    def _():
        sgs = _client("ec2").describe_security_groups().get("SecurityGroups", [])
        needle = name_substring.lower()
        matches = [
            {"GroupId": s["GroupId"], "GroupName": s["GroupName"], "Description": s["Description"]}
            for s in sgs
            if needle in s["GroupName"].lower()
            or needle in (s.get("Description") or "").lower()
            or any(needle in (t.get("Value") or "").lower() for t in s.get("Tags", []))
        ]
        return {"matches": matches, "count": len(matches)}
    return _()


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 4: EC2 INSTANCES (2 tools)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def find_instance(query: str) -> dict:
    """Locate an EC2 instance by Name tag (substring) or instance id.
    Returns SGs, subnet, private/public IPs, state — perfect for incident triage.

    Args:
        query: Instance id (i-...) or substring of the Name tag.
    """
    @_safe
    def _():
        ec2 = _client("ec2")
        if query.startswith("i-"):
            instances = ec2.describe_instances(InstanceIds=[query])
        else:
            instances = ec2.describe_instances(
                Filters=[{"Name": "tag:Name", "Values": [f"*{query}*"]}]
            )
        results = []
        for r in instances.get("Reservations", []):
            for i in r.get("Instances", []):
                results.append({
                    "InstanceId": i["InstanceId"],
                    "Name": next((t["Value"] for t in i.get("Tags", []) if t["Key"] == "Name"), None),
                    "State": i["State"]["Name"],
                    "PrivateIpAddress": i.get("PrivateIpAddress"),
                    "PublicIpAddress": i.get("PublicIpAddress"),
                    "SubnetId": i.get("SubnetId"),
                    "VpcId": i.get("VpcId"),
                    "SecurityGroups": [{"Id": sg["GroupId"], "Name": sg["GroupName"]} for sg in i.get("SecurityGroups", [])],
                    "InstanceType": i.get("InstanceType"),
                    "LaunchTime": i.get("LaunchTime"),
                })
        return {"instances": results, "count": len(results)}
    return _()


@mcp.tool()
def find_ip_address(ip: str, regions: Optional[list[str]] = None) -> dict:
    """Locate which ENI / EC2 holds an IP address — searches across regions.

    Args:
        ip: IP address, e.g. '10.50.4.17' or a public IPv4.
        regions: List of regions to search. Default: just current region.
    """
    @_safe
    def _():
        regions_to_search = regions or [REGION]
        results = []
        for region in regions_to_search:
            ec2 = _client("ec2", region=region)
            try:
                enis = ec2.describe_network_interfaces(
                    Filters=[{"Name": "addresses.private-ip-address", "Values": [ip]}]
                ).get("NetworkInterfaces", [])
                for eni in enis:
                    results.append({
                        "Region": region,
                        "NetworkInterfaceId": eni["NetworkInterfaceId"],
                        "InstanceId": eni.get("Attachment", {}).get("InstanceId"),
                        "PrivateIp": eni["PrivateIpAddress"],
                        "Description": eni.get("Description"),
                    })
            except ClientError:
                pass
        return {"matches": results, "searched_regions": regions_to_search}
    return _()


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 5: VPN / TGW / DIRECT CONNECT (2 tools)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def list_vpn_connections() -> dict:
    """List all Site-to-Site VPNs with both tunnels' UP/DOWN state and Customer
    Gateway peer IP. Use for VPN flap troubleshooting."""
    @_safe
    def _():
        vpns = _client("ec2").describe_vpn_connections().get("VpnConnections", [])
        return [{
            "VpnConnectionId": v["VpnConnectionId"],
            "State": v["State"],
            "CustomerGatewayId": v.get("CustomerGatewayId"),
            "VpnGatewayId": v.get("VpnGatewayId"),
            "TransitGatewayId": v.get("TransitGatewayId"),
            "Tunnels": [{
                "OutsideIpAddress": t.get("OutsideIpAddress"),
                "Status": t.get("Status"),
                "StatusMessage": t.get("StatusMessage"),
                "LastStatusChange": t.get("LastStatusChange"),
            } for t in v.get("VgwTelemetry", [])],
        } for v in vpns]
    return _()


@mcp.tool()
def describe_customer_gateways() -> dict:
    """Show registered Customer Gateways (your on-prem firewall public IPs and
    BGP ASNs)."""
    @_safe
    def _():
        return _client("ec2").describe_customer_gateways()
    return _()


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 6: REACHABILITY / FLOW LOGS (3 tools)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def get_path_trace_methodology() -> dict:
    """Return a systematic 7-step network troubleshooting checklist. ALWAYS
    call this first when the user reports a connectivity problem — it gives
    you (the AI) the right order to check things in."""
    return {
        "methodology": [
            "1. Confirm source & destination IPs/instances exist (find_instance, find_ip_address)",
            "2. Check Security Groups on BOTH source and destination (describe_security_group)",
            "3. Check NACLs on both subnets — they're stateless, both directions matter (describe_nacls)",
            "4. Check route tables — does the source subnet's route table have a path to dest? (describe_route_tables)",
            "5. If cross-VPC: check TGW/VPC peering routes and SG references",
            "6. If on-prem: check VPN tunnel state and CGW (list_vpn_connections)",
            "7. Run analyze_vpc_reachability for AWS's own packet path simulation",
        ],
        "common_mistakes": [
            "Forgetting NACLs allow rules need both inbound AND outbound (stateless)",
            "Assuming SG-to-SG references work cross-VPC (they don't, except via peering)",
            "Missing the ephemeral port range (32768-65535) in NACL outbound rules",
        ],
    }


@mcp.tool()
def analyze_vpc_reachability(source: str, destination: str) -> dict:
    """Run AWS Reachability Analyzer to trace why packet A can't reach B.
    AWS-native packet path simulation — gives you the exact firewall rule
    or routing entry blocking traffic.

    Args:
        source: ENI id, instance id, or IGW id (the start of the path).
        destination: ENI id, instance id, or IGW id (the destination).
    """
    @_safe
    def _():
        ec2 = _client("ec2")
        path = ec2.create_network_insights_path(
            Source=source,
            Destination=destination,
            Protocol="tcp",
        )["NetworkInsightsPath"]
        analysis = ec2.start_network_insights_analysis(
            NetworkInsightsPathId=path["NetworkInsightsPathId"]
        )
        return {
            "PathId": path["NetworkInsightsPathId"],
            "AnalysisId": analysis["NetworkInsightsAnalysis"]["NetworkInsightsAnalysisId"],
            "Status": analysis["NetworkInsightsAnalysis"]["Status"],
            "note": "Analysis runs async. Call get_reachability_result with AnalysisId in 30 sec.",
        }
    return _()


@mcp.tool()
def query_flow_logs(log_group: str, query: str, hours_back: int = 1) -> dict:
    """Run a CloudWatch Logs Insights query against a VPC Flow Logs log group.

    Args:
        log_group: CloudWatch Logs log group name, e.g. '/aws/vpc/flow-logs'.
        query: Logs Insights query string. Example:
               'fields @timestamp, srcAddr, dstAddr, action | filter action="REJECT" | limit 50'
        hours_back: How many hours of history to search (default 1).
    """
    @_safe
    def _():
        logs = _client("logs")
        end = int(datetime.now(timezone.utc).timestamp())
        start = end - (hours_back * 3600)
        query_id = logs.start_query(
            logGroupName=log_group,
            startTime=start,
            endTime=end,
            queryString=query,
        )["queryId"]
        return {
            "queryId": query_id,
            "note": "Use get_flow_log_results with this queryId in 5-10 seconds.",
        }
    return _()


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 7: CLOUDTRAIL (2 tools)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def lookup_events(event_name: str, hours_back: int = 24) -> dict:
    """Search CloudTrail for a specific API call. Useful for 'who deleted X?'
    or 'when did this rule change?' investigations.

    Args:
        event_name: CloudTrail event name, e.g. 'DeleteSecurityGroup', 'TerminateInstances'.
        hours_back: How far back to look (default 24).
    """
    @_safe
    def _():
        end = datetime.now(timezone.utc)
        start = end - timedelta(hours=hours_back)
        events = _client("cloudtrail").lookup_events(
            LookupAttributes=[{"AttributeKey": "EventName", "AttributeValue": event_name}],
            StartTime=start,
            EndTime=end,
            MaxResults=50,
        ).get("Events", [])
        return [{
            "EventName": e["EventName"],
            "EventTime": e["EventTime"],
            "Username": e.get("Username"),
            "Resources": e.get("Resources"),
            "EventSource": e.get("EventSource"),
        } for e in events]
    return _()


@mcp.tool()
def find_who_deleted(resource_id: str, hours_back: int = 168) -> dict:
    """Find who deleted/modified a resource. Searches the last 7 days by default.

    Args:
        resource_id: Resource id, e.g. 'sg-0abc123', 'i-0xyz', 'vpc-0def'.
        hours_back: Lookback window (default 168 = 7 days).
    """
    @_safe
    def _():
        end = datetime.now(timezone.utc)
        start = end - timedelta(hours=hours_back)
        events = _client("cloudtrail").lookup_events(
            LookupAttributes=[{"AttributeKey": "ResourceName", "AttributeValue": resource_id}],
            StartTime=start,
            EndTime=end,
            MaxResults=50,
        ).get("Events", [])
        # Filter for write events
        write_events = [e for e in events if any(
            verb in e["EventName"] for verb in ["Delete", "Modify", "Update", "Replace", "Revoke", "Authorize"]
        )]
        return {
            "resource": resource_id,
            "write_events": [{
                "EventName": e["EventName"],
                "EventTime": e["EventTime"],
                "Username": e.get("Username"),
            } for e in write_events],
        }
    return _()


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 8: LOAD BALANCERS (2 tools)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def describe_load_balancers() -> dict:
    """List Application/Network Load Balancers with state and DNS name."""
    @_safe
    def _():
        elbv2 = _client("elbv2")
        lbs = elbv2.describe_load_balancers().get("LoadBalancers", [])
        return [{
            "Name": lb["LoadBalancerName"],
            "Arn": lb["LoadBalancerArn"],
            "DNSName": lb["DNSName"],
            "Type": lb["Type"],
            "Scheme": lb["Scheme"],
            "State": lb["State"]["Code"],
            "VpcId": lb["VpcId"],
        } for lb in lbs]
    return _()


@mcp.tool()
def describe_target_health(target_group_arn: str) -> dict:
    """Get health of all targets in a target group. Find the unhealthy ones.

    Args:
        target_group_arn: Full ARN of the target group.
    """
    @_safe
    def _():
        return _client("elbv2").describe_target_health(TargetGroupArn=target_group_arn)
    return _()


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 9: AWS NATIVE FINDINGS (3 tools)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def get_security_hub_findings(severity: str = "HIGH", max_results: int = 25) -> dict:
    """Get current Security Hub findings filtered by severity.

    Args:
        severity: One of CRITICAL, HIGH, MEDIUM, LOW.
        max_results: Max findings to return (default 25).
    """
    @_safe
    def _():
        return _client("securityhub").get_findings(
            Filters={
                "SeverityLabel": [{"Value": severity, "Comparison": "EQUALS"}],
                "RecordState": [{"Value": "ACTIVE", "Comparison": "EQUALS"}],
            },
            MaxResults=max_results,
        )
    return _()


@mcp.tool()
def get_guardduty_findings(severity_min: float = 7.0) -> dict:
    """Get current GuardDuty findings above a severity threshold.

    Args:
        severity_min: Minimum severity (1.0-8.9). 7.0+ = HIGH.
    """
    @_safe
    def _():
        gd = _client("guardduty")
        detectors = gd.list_detectors().get("DetectorIds", [])
        if not detectors:
            return {"findings": [], "note": "GuardDuty not enabled in this region"}
        finding_ids = gd.list_findings(
            DetectorId=detectors[0],
            FindingCriteria={"Criterion": {"severity": {"Gte": severity_min}}},
            MaxResults=20,
        ).get("FindingIds", [])
        if not finding_ids:
            return {"findings": []}
        return gd.get_findings(DetectorId=detectors[0], FindingIds=finding_ids)
    return _()


@mcp.tool()
def get_inspector_findings(severity: str = "HIGH") -> dict:
    """Get current Inspector v2 findings (vulnerability scanning).

    Args:
        severity: CRITICAL, HIGH, MEDIUM, LOW.
    """
    @_safe
    def _():
        return _client("inspector2").list_findings(
            filterCriteria={
                "severity": [{"comparison": "EQUALS", "value": severity}],
            },
            maxResults=25,
        )
    return _()


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 10: FINOPS (1 tool)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def get_cost_and_usage(days_back: int = 30, group_by: str = "SERVICE") -> dict:
    """Get AWS spend grouped by service, account, or region.

    Args:
        days_back: How many days of history (default 30).
        group_by: 'SERVICE', 'LINKED_ACCOUNT', or 'REGION'.
    """
    @_safe
    def _():
        end = datetime.now(timezone.utc).date()
        start = end - timedelta(days=days_back)
        return _client("ce", region="us-east-1").get_cost_and_usage(
            TimePeriod={"Start": str(start), "End": str(end)},
            Granularity="DAILY",
            Metrics=["UnblendedCost"],
            GroupBy=[{"Type": "DIMENSION", "Key": group_by}],
        )
    return _()


# ═════════════════════════════════════════════════════════════════════════════
# CATEGORY 11: AWS DOCS SEARCH (1 tool)
# ═════════════════════════════════════════════════════════════════════════════

@mcp.tool()
def aws_docs_search(query: str) -> dict:
    """Return a guidance hint pointing to AWS documentation. Use this when
    the user asks 'how do I...' — point them to the right service guide.

    Args:
        query: User's question or topic.
    """
    return {
        "query": query,
        "search_url": f"https://docs.aws.amazon.com/search/doc-search.html?searchPath=documentation&searchQuery={query}",
        "note": "Suggest the user verify by clicking the search URL.",
    }


# ─────────────────────────────────────────────────────────────────────────────
# NOTE: This is a representative subset (~25 tools shown for clarity).
# Your production version has 104 tools across 21 categories. Add more by
# following the @mcp.tool() pattern above. Each tool needs:
#   - A clear docstring (the AI reads this to decide when to call it)
#   - Type hints (become the JSON schema)
#   - Wrapped in _safe() so AWS errors return readable JSON
# ─────────────────────────────────────────────────────────────────────────────


if __name__ == "__main__":
    # When run directly, serve over stdio for Claude Desktop
    mcp.run()
